package com.f2c.SpringBootSocialJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSocialJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSocialJpaApplication.class, args);
	}

}
