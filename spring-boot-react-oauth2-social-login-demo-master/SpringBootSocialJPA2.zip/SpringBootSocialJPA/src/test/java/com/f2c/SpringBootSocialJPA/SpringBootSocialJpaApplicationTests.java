package com.f2c.SpringBootSocialJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSocialJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
